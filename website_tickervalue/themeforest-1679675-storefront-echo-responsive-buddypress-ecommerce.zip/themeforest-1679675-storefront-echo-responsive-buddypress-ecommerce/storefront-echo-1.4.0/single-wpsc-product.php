<?php get_header(); ?>

				<div class="col_12">
				
					<div id="entry" class="pad20both pad20vertical">
						<?php if ( have_posts() ) : ?>
							<?php /* Start the Loop */ ?>
							<?php while ( have_posts() ) : the_post(); ?>
								<?php the_content(); ?>
							<?php endwhile; ?>
						<?php else : ?>
								<h1><?php _e( 'Nothing Found', 'storefront' ); ?></h1>
								<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storefront' ); ?></p>
								<?php get_search_form(); ?>
						<?php endif; ?>
					</div><!-- #pad20both -->
				</div><!-- #col_12 -->

<?php get_footer(); ?>