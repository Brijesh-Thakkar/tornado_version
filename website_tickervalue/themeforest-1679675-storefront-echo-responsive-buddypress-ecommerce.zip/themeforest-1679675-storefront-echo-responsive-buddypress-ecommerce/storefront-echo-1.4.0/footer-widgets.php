				<div id="content-bottom-border" class="col_12"></div>
				<div id="content-bottom" class="col_12">
					<div class="widget col_3">
						<?php dynamic_sidebar('Footer Widget 1'); ?>
					</div>
					
					<div class="widget col_3">
						<?php dynamic_sidebar('Footer Widget 2'); ?>
					</div>
					
					<div class="widget col_3">
						<?php dynamic_sidebar('Footer Widget 3'); ?>
					</div>
					
					<div class="widget col_3 last">
						<?php dynamic_sidebar('Footer Widget 4'); ?>
					</div>
										
				</div><!-- #content-bottom -->