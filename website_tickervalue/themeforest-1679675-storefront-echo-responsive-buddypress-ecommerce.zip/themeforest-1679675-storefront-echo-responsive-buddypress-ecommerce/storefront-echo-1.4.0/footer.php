				<div class="clear"></div>
					<?php require(TEMPLATEPATH . '/footer-widgets.php');?>
			</div><!-- #content -->
		</div><!-- #primary -->
</div><!-- //End of Main -->
<div class="row" id="footer">
	<div class="col_12"><p>
	<?php if ( get_option('storefront_footer_text')) { echo get_option('storefront_footer_text');} else {?>
	<?php _e( 'Copyright &copy; 2011 ', 'storefront' ); ?><a href="<?php bloginfo('url');?>"><?php bloginfo('name');?></a>
	<?php } ?>
	</p></div>
</div>
</div><!-- //End of container -->
<?php wp_footer(); ?>
</body>
</html>