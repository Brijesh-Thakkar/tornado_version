<?php get_header( 'buddypress' ) ?>

<!-- TEMPLATE START OPEN -->
				<div class="col_12">
					<div class="pad20both pad20vertical">
<!-- TEMPLATE START CLOSE -->

<div class="activity no-ajax" role="main">
	<?php if ( bp_has_activities( 'display_comments=threaded&show_hidden=true&include=' . bp_current_action() ) ) : ?>

		<ul id="activity-stream" class="activity-list item-list">
		<?php while ( bp_activities() ) : bp_the_activity(); ?>

			<?php locate_template( array( 'activity/entry.php' ), true ) ?>

		<?php endwhile; ?>
		</ul>

	<?php endif; ?>
</div>
<!-- TEMPLATE END OPEN -->
					</div>
				</div>
<!-- TEMPLATE END CLOSE -->
<?php get_footer( 'buddypress' ) ?>