<?php get_header(); ?>

				<div class="col_12">
					<div id="entry" class="pad20both pad20vertical">
						<?php if ( have_posts() ) : ?>
							
							<?php /* Start the Loop */
							global $wp_query;
							$args = array_merge( $wp_query->query, array( 'post_type' => array('page') ) );
							query_posts( $args );
							 ?>
							<div class="col_2 searchcolumn">
							<h2><?php _e( 'Pages', 'storefront' ); ?></h2>
								<?php if (have_posts()) {?>
									<?php while ( have_posts() ) : the_post(); ?>
										<h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
										<div class="contenthr"></div>
									<?php endwhile; ?>
								<?php } else {_e( 'There are no pages that match your query.', 'storefront themes' );}?>
							</div><!-- .col_8 -->
							
							
							<?php /* Start the Loop */
							global $wp_query;
							$args = array_merge( $wp_query->query, array( 'post_type' => array('post') ) );
							query_posts( $args );
							 ?>
							<div class="col_8 searchcolumn postcolumn">
							<h2><?php _e( 'From the Blog', 'storefront' ); ?></h2>
								<?php if (have_posts()) {?>
									<?php while ( have_posts() ) : the_post(); ?>
										<div class="post">
										
										<?php 
										if(has_post_thumbnail()) {
										if (get_option('storefront_blog_image_height')) {$blogimageheight = get_option('storefront_blog_image_height');}
										else {$blogimageheight = 125;}
										if (get_option('storefront_blog_image_width')) {$blogimagewidth = get_option('storefront_blog_image_width');}
										else {$blogimagewidth = 125;}
										$thumb = get_post_thumbnail_id(); 
										$image = vt_resize( $thumb, '', $blogimagewidth, $blogimageheight, true );
										$largeimage = vt_resize( $thumb, '', 900, 700, true );
										?>
										<a href="<?php echo $largeimage['url']; ?>" class="fancybox-image" rel="<?php the_title(); ?>">
										<img src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" />
										</a>
										<?php } ?>
										<h3><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h3>
										<?php the_excerpt(); ?>
										<div class="contenthr"></div>
										</div>
									<?php endwhile; ?>
								<?php } else {_e( 'There are no blog posts that match your query.', 'storefront themes' );}?>
							</div><!-- .col_8 -->
							
							
							
							
							<?php
if ( in_array( 'wp-e-commerce/wp-shopping-cart.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { ?>

							<?php /* Start the Loop */
							global $wp_query;
							$args = array_merge( $wp_query->query, array( 'post_type' => array('wpsc-product') ) );
							query_posts( $args );
							 ?>
							<div class="col_2 searchcolumn last">
							<h2><?php _e( 'Products', 'storefront' ); ?></h2>
							<?php if (have_posts()) {?>
								<?php while ( have_posts() ) : the_post(); ?>
									<div class="searchedproduct">
									<a rel="<?php echo wpsc_the_product_title(); ?>" class="<?php echo wpsc_the_product_image_link_classes(); ?><?php if ( get_option('storefront_product_image_link') == "image" ) {echo " fancybox-image";} ?>" href="<?php if ( get_option('storefront_product_image_link') == "image" ) {echo wpsc_the_product_image();} else {echo wpsc_the_product_permalink();} ?>">
									<img class="product_image" id="product_image_<?php echo wpsc_the_product_id(); ?>" alt="<?php echo wpsc_the_product_title(); ?>" title="<?php echo wpsc_the_product_title(); ?>" src="<?php echo wpsc_the_product_thumbnail(); ?>"/>
									</a>
									<h3>
										<?php if(get_option('hide_name_link') == 1) : ?>
											<?php echo wpsc_the_product_title(); ?>
										<?php else: ?> 
											<?php echo wpsc_the_product_title(); ?>
										<?php endif; ?>
									</h3>
	
									<a class="button" href="<?php the_permalink();?>"><?php echo wpsc_the_product_price(); ?></a>
									<div class="contenthr"></div>
									</div>
								<?php endwhile; ?>
							<?php } else {_e( 'There are no products that match your query.', 'storefront themes' );}?>
							</div>

<?php } elseif ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { ?>

							<?php /* Start the Loop */
							global $wp_query;
							$args = array_merge( $wp_query->query, array( 'post_type' => array('product') ) );
							query_posts( $args );
							 ?>
							<div class="col_2 searchcolumn last">
							<h2><?php _e( 'Products', 'storefront' ); ?></h2>
							<?php if (have_posts()) {?>
								<?php while ( have_posts() ) : the_post(); ?>
									<div class="searchedproduct">
															  		<?php
						  		if(has_post_thumbnail()) {
						  			   $carimgwidth = 125;
						  			   $carouselheight = 125;
							  		   $thumb = get_post_thumbnail_id(); 
									   $image = vt_resize( $thumb, '', $carimgwidth, $carouselheight, true );
									 ?>
							    	 <a href="<?php echo the_permalink(); ?>" title="<?php the_title(); ?>">
							    	 <img alt="<?php the_title(); ?>"  src="<?php echo $image['url']; ?>" width="<?php echo $carimgwidth;?>px" height="<?php echo $carouselheight;?>px" />
							    	 </a>
						    	 <?php } else {?>
							    	 <a href="<?php echo the_permalink(); ?>" title="<?php the_title(); ?>">
							    	 <img alt="<?php the_title(); ?>"  src="<?php echo $woocommerce->plugin_url() ?>/assets/images/placeholder.png" width="<?php echo $carimgwidth;?>px" height="<?php echo $carouselheight;?>px" />
							    	 </a>
						    	 <?php }?>
									<h3>
										<?php if(get_option('hide_name_link') == 1) : ?>
											<?php echo the_title(); ?>
										<?php else: ?> 
											<?php echo the_title(); ?>
										<?php endif; ?>
									</h3>
	
									<a class="button" href="<?php the_permalink();?>"><?php echo $product->get_price_html(); ?></a>
									<div class="contenthr"></div>
									</div>
								<?php endwhile; ?>
							<?php } else {_e( 'There are no products that match your query.', 'storefront themes' );}?>
							</div>

<?php } elseif ( in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { ?>

							<?php /* Start the Loop */
							global $wp_query;
							$args = array_merge( $wp_query->query, array( 'post_type' => array('product') ) );
							query_posts( $args );
							 ?>
							<div class="col_2 searchcolumn last">
							<h2><?php _e( 'Products', 'storefront' ); ?></h2>
							<?php if (have_posts()) {?>
								<?php while ( have_posts() ) : the_post(); ?>
									<div class="searchedproduct">
															  		<?php
						  		if(has_post_thumbnail()) {
						  			   $carimgwidth = 125;
						  			   $carouselheight = 125;
							  		   $thumb = get_post_thumbnail_id(); 
									   $image = vt_resize( $thumb, '', $carimgwidth, $carouselheight, true );
									 ?>
							    	 <a href="<?php echo the_permalink(); ?>" title="<?php the_title(); ?>">
							    	 <img alt="<?php the_title(); ?>"  src="<?php echo $image['url']; ?>" width="<?php echo $carimgwidth;?>px" height="<?php echo $carouselheight;?>px" />
							    	 </a>
						    	 <?php } else {?>
							    	 <a href="<?php echo the_permalink(); ?>" title="<?php the_title(); ?>">
							    	 <img alt="<?php the_title(); ?>"  src="<?php bloginfo( 'template_url' ); ?>/images/placeholder.png" width="<?php echo $carimgwidth;?>px" height="<?php echo $carouselheight;?>px" />
							    	 </a>
						    	 <?php }?>
									<h3>
										<?php echo the_title(); ?>
									</h3>
	
									<a class="button" href="<?php the_permalink();?>"><?php _e( 'View Product', 'storefront' ); ?></a>
									<div class="clear"></div>
									<div class="contenthr"></div>
									</div>
								<?php endwhile; ?>
							<?php } else {_e( 'There are no products that match your query.', 'storefront themes' );}?>
							</div>

<?php
}
?>							
							
						<?php else : ?>
								<h1><?php _e( 'Nothing Found', 'storefront' ); ?></h1>
								<p><?php _e( 'There were no results found that match your query.', 'storefront themes' ); ?></p>
						<?php endif; ?>
						
						
						
	<div class="clear"></div>
					</div><!-- #pad20both -->
				</div><!-- #col_12 -->

<?php get_footer(); ?>