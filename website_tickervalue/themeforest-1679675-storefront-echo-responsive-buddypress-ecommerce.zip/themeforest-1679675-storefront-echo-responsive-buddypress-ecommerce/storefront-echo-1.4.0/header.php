<?php global $woocommerce;?>
<!doctype html>  
<!--[if lt IE 7 ]> <html lang="<?php language_attributes(); ?>" class="no-js ie6"> <![endif]--> 
<!--[if IE 7 ]>    <html lang="<?php language_attributes(); ?>" class="no-js ie7"> <![endif]--> 
<!--[if IE 8 ]>    <html lang="<?php language_attributes(); ?>" class="no-js ie8"> <![endif]--> 
<!--[if IE 9 ]>    <html lang="<?php language_attributes(); ?>" class="no-js ie9"> <![endif]-->   
<!--[if (gt IE 9)|!(IE)]><!--> <html lang="<?php language_attributes(); ?>" class="no-js"> <!--<![endif]--> 
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<title>
<?php /* Print the <title> tag based on what is being viewed. */
	global $page, $paged;wp_title( '|', true, 'right' );
	
	// Add the blog name.
	bloginfo( 'name' );

	// Add the blog description for the home/front page.
	$site_description = bloginfo( 'description', 'display' );
	if ( $site_description && ( is_home() || is_front_page() ) )
		echo " | $site_description";

	// Add a page number if necessary:
	if ( $paged >= 2 || $page >= 2 ) echo ' | ' . sprintf( __( 'Page %s', 'storefront' ), max( $paged, $page ) );
?>
</title>

<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
 
<!-- Fixes for IE --> 
	<!--[if IE]>
    	<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie.css" type="text/css" media="screen" />
	<![endif]--> 
 
	<!-- use "fixed-984px-ie.css" or "fixed-960px-ie.css for a 984px or 960px fixed width for IE6 and 7 --> 
		<!--[if lte IE 7]>
			<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/fixed-984px-ie.css" type="text/css" media="screen" />
		<![endif]--> 
	 
	<!-- Fixes for IE6, only needed if IE 6 will be supported - width must match 984px or 960px of css file used above --> 
	<!-- Use .imagescale to fix IE6 issues with full-column width images (class must be added to any image wider than the column it is placed into) --> 
		<!--[if lte IE 6]>
			<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/css/ie6-984px.css" type="text/css" media="screen" />
		<![endif]--> 
<!-- End fixes for IE -->

<link rel="profile" href="http://gmpg.org/xfn/11" />
<link rel="stylesheet" type="text/css" media="all" href="<?php bloginfo( 'stylesheet_url' ); ?>" />
<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>" />
<!-- Load Modernizr which enables HTML5 elements & feature detects -->
<script src="<?php echo get_template_directory_uri(); ?>/js/modernizr-2.0.6.min.js"></script>	
<?php wp_head();?>

<!-- Scripts -->
<?php require(TEMPLATEPATH . '/includes/custom-style.php'); ?>
</head>

<body <?php body_class(); ?>>
<div class="container pad20vertical">
<div id="header" class="row">
	<div class="alignleft" id="logo">
		<?php if ( get_option('storefront_logo') ) { ?>
		            <a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('description'); ?>"><img src="<?php echo get_option('storefront_logo'); ?>" /></a>
		        <?php } else { ?>
		<h1><a href="<?php bloginfo('url');?>"><?php echo get_option("storefront_logo_text");?></a></h1>
		<?php } ?>
	</div>
		<div class="alignright pad20bottom" id="header-right">
		
	<div class="mobilesearch">
	<?php get_search_form(); ?>
	</div>
		<div class="box" id="nav-container">		
			<div id="navwrap">
			<?php storefront_mainnav(); ?>
			<?php if ( get_option('storefront_show_nav_cart') == 'true' ) {?>
			
				<?php require(TEMPLATEPATH . '/includes/nav-cart.php'); ?>
				
			<?php } ?>
			<?php if ( function_exists( 'bp_include' ) ) { ?>
			<?php if ( get_option('storefront_show_nav_community') == 'true' ) {?>
				<div id="navcommunity">
					<span id="navcommunitybutton" class="showcommunity"></span>
					<div id="communitylinks">
						<?php require(TEMPLATEPATH . '/includes/navcommunity.php'); ?>
					</div>
				</div>
			<?php } ?>
			<?php } ?>
			
			<?php if ( get_option('storefront_show_nav_search') == 'true' ) {?>
				<div class="navsearch">
				<?php get_search_form(); ?>
				</div>
			<?php } ?>
			<div class="clear"></div>
			</div>
		</div>
		</div>
		<div class="clear"></div>
</div>
<div id="main">

		<div id="primary">
					<?php if ( is_page() ) {$pageid = (int) $wp_query->post->ID;$template = get_post_meta($pageid, '_wp_page_template', true);}?>
			<div id="content" class="row box<?php if($template = 'tpl-home.php') {echo ' homerow';}?>">
			