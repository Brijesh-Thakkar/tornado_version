<?php
if (!is_admin()) add_action( 'wp_print_scripts', 'storefrontthemes_add_javascript' );
function storefrontthemes_add_javascript( ) {

		if(function_exists('bp_exists') && bp_is_activity_component()) {wp_enqueue_script('jquery');} else {
		//deregister wordpress version of jquery, then load jquery from google api, and place in footer
        wp_deregister_script('jquery');
		wp_register_script('jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js', false, '1.4.4');
		wp_enqueue_script('jquery');
		}
		
        // Register and enqueue the fancybox script
        wp_register_script( 'fancybox', get_template_directory_uri() . '/js/jquery.fancybox-1.3.4.pack.js', 'jquery' );
        wp_enqueue_script( 'fancybox' );
        
        // Register and enqueue the storefront fancy cart script
        wp_register_script( 'sftfancycart', get_template_directory_uri() . '/js/sft-fancycart.js', 'jquery' );
        wp_enqueue_script( 'sftfancycart' );
        
        // Register and enqueue the blueberry slider script
        wp_register_script( 'blueberry', get_template_directory_uri() . '/js/jquery.blueberry.js', 'jquery' );
        wp_enqueue_script( 'blueberry' );

        // Register and enqueue the flexslider carousel script        
        wp_register_script( 'flexslider', get_template_directory_uri() . '/js/jquery.flexslider-min.js', 'jquery' );
        wp_enqueue_script( 'flexslider' );

        // Register and enqueue the buddynav script
        wp_register_script( 'buddynav', get_template_directory_uri() . '/js/buddynav.js', 'jquery' );
        wp_enqueue_script( 'buddynav' );
 
}
?>