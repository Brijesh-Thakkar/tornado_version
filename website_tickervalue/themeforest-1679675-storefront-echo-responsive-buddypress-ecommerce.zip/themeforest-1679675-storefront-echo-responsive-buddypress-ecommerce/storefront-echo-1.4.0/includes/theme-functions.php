<?php

add_theme_support( 'post-thumbnails' );
add_theme_support( 'automatic-feed-links' );
if ( ! isset( $content_width ) ) $content_width = 960;
/*
===============================================================
BUDDYPRESS SCRIPTS
===============================================================
*/
if ( !function_exists( 'bp_dtheme_enqueue_scripts' ) ) :
/**
 * Enqueue theme javascript safely
 *
 * @see http://codex.wordpress.org/Function_Reference/wp_enqueue_script
 * @since 1.5
 */
function bp_dtheme_enqueue_scripts() {
	// Bump this when changes are made to bust cache
	$version = '20120208';

	// Enqueue the global JS - Ajax will not work without it
	wp_enqueue_script( 'dtheme-ajax-js', get_template_directory_uri() . '/_inc/global.js', array( 'jquery' ), $version );

	// Add words that we need to use in JS to the end of the page so they can be translated and still used.
	$params = array(
		'my_favs'           => __( 'My Favorites', 'buddypress' ),
		'accepted'          => __( 'Accepted', 'buddypress' ),
		'rejected'          => __( 'Rejected', 'buddypress' ),
		'show_all_comments' => __( 'Show all comments for this thread', 'buddypress' ),
		'show_all'          => __( 'Show all', 'buddypress' ),
		'comments'          => __( 'comments', 'buddypress' ),
		'close'             => __( 'Close', 'buddypress' ),
		'view'              => __( 'View', 'buddypress' )
	);

	wp_localize_script( 'dtheme-ajax-js', 'BP_DTheme', $params );
}
add_action( 'wp_enqueue_scripts', 'bp_dtheme_enqueue_scripts' );
endif;

/*
===============================================================
WIDGET AREAS
===============================================================
*/

if ( function_exists('register_sidebar') )
    register_sidebar(array(
    	'name'=>'Footer Widget 1',
        'before_widget' => '<div class="footwidget1 widget %2$s">',
        'after_widget' => '<div class="clear"></div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3><div class="underline"></div>',
    ));
if ( function_exists('register_sidebar') )
    register_sidebar(array(
    	'name'=>'Footer Widget 2',
        'before_widget' => '<div class="footwidget2 widget %2$s">',
        'after_widget' => '<div class="clear"></div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3><div class="underline"></div>',
    ));
if ( function_exists('register_sidebar') )
    register_sidebar(array(
    	'name'=>'Footer Widget 3',
        'before_widget' => '<div class="footwidget3 widget %2$s">',
        'after_widget' => '<div class="clear"></div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3><div class="underline"></div>',
    ));
if ( function_exists('register_sidebar') )
    register_sidebar(array(
    	'name'=>'Footer Widget 4',
        'before_widget' => '<div class="footwidget4 widget %2$s">',
        'after_widget' => '<div class="clear"></div></div>',
        'before_title' => '<h3>',
        'after_title' => '</h3><div class="underline"></div>',
    ));


    
/*
===============================================================
REGISTER CUSTOM MENUS
===============================================================
*/
add_theme_support( 'menus' );

add_action( 'init', 'register_my_menus' );

function register_my_menus() {
	register_nav_menus(
		array(
			'primary-menu' => __( 'Main Navigation','storefront' )/*,
			'secondary-menu' => __( 'Footer Navigation' )*/
		)
	);
}

//MAIN NAV
function storefront_mainnav() {
    if ( function_exists( 'wp_nav_menu' ) )
        wp_nav_menu( 'theme_location=primary-menu&container=&menu_id=nav&menu_class=&fallback_cb=storefront_mainnav_fallback&items_wrap=<ul id=nav class=>%3$s<li></li></ul>' );
    else
        storefront_mainnav_fallback();
}

function storefront_mainnav_fallback() {
    echo '<ul id="nav">';
    wp_list_pages('sort_column=menu_order&depth=3&title_li=&exclude='.get_option('storefront_nav_exclude'));
    echo '</ul>';
}

if ( function_exists( 'add_theme_support' ) ) { 
  add_theme_support( 'post-thumbnails' ); 
}


/*
===============================================================
Custom Post Type For Slider
===============================================================
*/

		add_action('init', 'create_slider_post_type');
	
		function create_slider_post_type() {
	    	$args = array(
	        	'label' => __('Slider','storefront'),
	        	'singular_label' => __('Slide','storefront'),
	        	'public' => true,
	        	'show_ui' => true,
	        	'capability_type' => 'post',
	        	'hierarchical' => false,
	        	'rewrite' => true,
	        	'exclude_from_search' => true,
        		'labels' => array(
					'name' => __( 'Slider','storefront' ),
					'singular_name' => __( 'Slide','storefront' ),
					'add_new' => __( 'Add New','storefront' ),
					'add_new_item' => __( 'Add New Slide','storefront' ),
					'edit' => __( 'Edit','storefront' ),
					'edit_item' => __( 'Edit Slide','storefront' ),
					'new_item' => __( 'New Slide','storefront' ),
					'view' => __( 'View Slide','storefront' ),
					'view_item' => __( 'View Slide','storefront' ),
					'search_items' => __( 'Search Slides','storefront' ),
					'not_found' => __( 'No slides found','storefront' ),
					'not_found_in_trash' => __( 'No slides found in Trash','storefront' ),
					'parent' => __( 'Parent Slide','storefront' ),
				),
	        	'supports' => array('title', 'thumbnail')
	        );
	
	    	register_post_type( 'slide' , $args );
	
	?>
<?php
/*
===============================================================
Icon For Slider
===============================================================
*/
add_action( 'admin_head', 'my_custom_posttype_icon' );
function my_custom_posttype_icon() {
    ?>
    <style type="text/css" media="screen">
    /*<![CDATA[*/
        #menu-posts-slide .wp-menu-image {
            background: url("<?php bloginfo( 'template_url' );?>/images/slider-menu-icon.png") no-repeat 0px -33px !important;
        }
                #menu-posts-slide:hover .wp-menu-image, #menu-posts-slide.wp-has-current-submenu .wp-menu-image {
            background: url("<?php bloginfo( 'template_url' );?>/images/slider-menu-icon.png") no-repeat 0px -1px !important;
        }
    /*]]>*/
    </style>
    <?php
}

/*
===============================================================
Options For Slider
===============================================================
*/
	
		add_action("admin_init", "admin_init");
		add_action('save_post', 'save_slide_meta');
	
		function admin_init(){
			add_meta_box("slider-meta", "Slider Options", "meta_options", "slide", "normal", "low");
		}
	
		function meta_options(){
			global $post;
			$custom = get_post_custom($post->ID);
			$link = $custom["link"][0];
	?>
	<p>Set a featured image for this slide using the built-in WordPress featured image feature which is normally located on the right hand side of this page.  </p><p>Then, enter a url (beginning with "http://") of a page, post, product, category or even an off-site link using the field below.</p><br />
		<label style="width:80px;float:left;display:block;font-weight:bold;padding:5px;">Link URL:</label><input style="width:400px;border:1px solid #ccc;" name="link" value="<?php echo $link; ?>" /><br />
	<?php
		}
	
	function save_slide_meta(){
		global $post;
		update_post_meta($post->ID, "link", $_POST["link"]);
	}
} //END OF CHECK FOR CUSTOM POST TYPE

/*
===============================================================
BLOG SETTINGS
===============================================================
*/ 

function new_excerpt_more($more) {
	return '...';
}
add_filter('excerpt_more', 'new_excerpt_more');

/*
===============================================================
WPEC SETTINGS
===============================================================
*/ 

/* Check if WPEC is active*/
if ( in_array( 'wp-e-commerce/wp-shopping-cart.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	// remove "from" on pricing
	function wpsc_remove_from_for_variations($from) {
	    return '';
	}
	 
	add_filter('wpsc_product_variation_text','wpsc_remove_from_for_variations');
	
	
	
	add_action( 'init', 'my_deregister_stuff', 100 );
	
	
	// REMOVE DEFAULT THICKBOX FUNCTION FROM WPEC
	function my_deregister_stuff() {
	wp_deregister_style( 'wpsc-thickbox' );
	wp_deregister_script( 'wpsc-thickbox' );
	}

}

/*
===============================================================
WOOCOMMERCE SETTINGS
===============================================================
*/ 
/* Check if WooCommerce is active */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
 
	define('WOOCOMMERCE_USE_CSS', true);
	
	
	if(get_option('storefront_woo_products_per_page')) {$woonumproducts = get_option('storefront_woo_products_per_page');} else {$woonumproducts = 12;}
	
	// Display the desired number of products per page
	add_filter('loop_shop_per_page', create_function('$cols', 'return '.$woonumproducts.';'));
	
	// Ensure cart contents update when products are added to the cart via AJAX
	add_filter('add_to_cart_fragments', 'woocommerceframework_header_add_to_cart_fragment');
	
	function woocommerceframework_header_add_to_cart_fragment( $fragments ) {
		
		
		ob_start();
		
		?>
		<span class='cartcount'><?php echo $woocommerce->cart->get_cart_total(); ?></span>
		<?php
	
		$fragments['.cartcount'] = ob_get_clean();
	
		return $fragments;
	
	}
	
	remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
	remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
	
	add_action('woocommerce_before_main_content', create_function('', 'echo "
					<div class=\"col_12\">
					<div id=\"entry\" class=\"pad20both pad20vertical\">
	";'), 10);
	
	add_action('woocommerce_after_main_content', create_function('', 'echo "
						</div><!-- #pad20both -->
					</div><!-- #col_12 -->
	";'), 10);
	
	remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10);

}

/*
===============================================================
JIGOSHOP SETTINGS
===============================================================
*/ 

/* Check if WooCommerce is active */
if ( in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {

	remove_action( 'jigoshop_before_main_content', 'jigoshop_output_content_wrapper', 10);
	remove_action( 'jigoshop_after_main_content', 'jigoshop_output_content_wrapper_end', 10);
	
	add_action('jigoshop_before_main_content', create_function('', 'echo "
					<div class=\"col_12\">
					<div id=\"entry\" class=\"pad20both pad20vertical\">
	";'), 10);
	
	add_action('jigoshop_after_main_content', create_function('', 'echo "
						</div><!-- #pad20both -->
					</div><!-- #col_12 -->
	";'), 10);
	
	remove_action( 'jigoshop_sidebar', 'jigoshop_get_sidebar', 10);

}

/*
===============================================================
TRUNCATE TITLES
===============================================================
*/

if (get_option('storefront_product_title_shorten')) {
add_action ('wp_head','add_jquery_stuff');  //put the query in the header

function add_jquery_stuff () {
?>
     <script type="text/javascript">
          function shorten(sometext,maxlen) { return ((sometext.length<=maxlen)?sometext:(sometext.substr(0,maxlen-3)+"...")); }
     </script>
     <?php
	     $shorten = get_option('storefront_product_title_shorten');
	 ?>

     <script type="text/javascript">
     jQuery(document).ready( function () {

          jQuery('h2.prodtitle,#content #entry ul.products li h3,body.jigoshop .products li strong').each(function(index){ //gets the link in all teaser headlines
                var t = jQuery(this).text();
                jQuery(this).text(shorten(t,<?php echo $shorten;?>)); //truncate to 28
          });
     });
    </script>
    
<?php
}
}

/*
===============================================================
BLOG COMMENTS
===============================================================
*/
function storefront_comment($comment, $args, $depth) {
   $GLOBALS['comment'] = $comment; ?>
   <li <?php comment_class(); ?> id="li-comment-<?php comment_ID() ?>">
     <div id="comment-<?php comment_ID(); ?>">
      <div class="comment-author vcard">
         <?php echo get_avatar( $comment->comment_author_email, 75 ); ?> 
      </div>
      
      <div class="comment-content">
	      <?php if ($comment->comment_approved == '0') : ?>
	         <em><?php _e('Your comment is awaiting moderation.','storefront') ?></em>
	         <br />
	      <?php endif; ?>
	
	      <div class="comment-meta commentmetadata"><a href="<?php echo esc_url( get_comment_link( $comment->comment_ID ) ) ?>"><?php printf(__('%1$s at %2$s','storefront'), get_comment_date(),  get_comment_time()) ?></a><?php edit_comment_link(__('(Edit)', 'storefront'),'  ','') ?></div>
		  <?php printf(__('<strong>%s says:</strong>','storefront'), get_comment_author_link()) ?>
	      <?php comment_text() ?>
	
	      <div class="reply">
	         <?php comment_reply_link(array_merge( $args, array('depth' => $depth, 'max_depth' => $args['max_depth']))) ?>
	      </div>
      </div>
      
      
      
     </div>
<?php
        }

/*
===============================================================
PRESS TRENDS
===============================================================
*/
// Presstrends
function presstrends() {

// Add your PressTrends and Theme API Keys
$api_key = 'h30d522gskg841feyj1t0jc1fu4nuimard29';
$auth = '1zy4cc72z2ql6oinan5icjl0j0pnpog0k';

// NO NEED TO EDIT BELOW
$data = get_transient( 'presstrends_data' );
if (!$data || $data == ''){
$api_base = 'http://api.presstrends.io/index.php/api/sites/add/auth/';
$url = $api_base . $auth . '/api/' . $api_key . '/';
$data = array();
$count_posts = wp_count_posts();
$count_pages = wp_count_posts('page');
$comments_count = wp_count_comments();
$theme_data = get_theme_data(get_stylesheet_directory() . '/style.css');
$plugin_count = count(get_option('active_plugins'));
$all_plugins = get_plugins();
foreach($all_plugins as $plugin_file => $plugin_data) {
$plugin_name .= $plugin_data['Name'];
$plugin_name .= '&';
}
$data['url'] = stripslashes(str_replace(array('http://', '/', ':' ), '', site_url()));
$data['posts'] = $count_posts->publish;
$data['pages'] = $count_pages->publish;
$data['comments'] = $comments_count->total_comments;
$data['approved'] = $comments_count->approved;
$data['spam'] = $comments_count->spam;
$data['theme_version'] = $theme_data['Version'];
$data['theme_name'] = $theme_data['Name'];
$data['site_name'] = str_replace( ' ', '', get_bloginfo( 'name' ));
$data['plugins'] = $plugin_count;
$data['plugin'] = urlencode($plugin_name);
$data['wpversion'] = get_bloginfo('version');
foreach ( $data as $k => $v ) {
$url .= $k . '/' . $v . '/';
}
$response = wp_remote_get( $url );
set_transient('presstrends_data', $data, 60*60*24);
}}

if ( get_option('storefront_presstrends') == 'true' ) {
	add_action('admin_init', 'presstrends');
}
?>