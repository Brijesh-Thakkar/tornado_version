<?php
add_action('init','storefront_options');  
function storefront_options(){
	
// VARIABLES
$themename = "Storefront Echo";
$manualurl = 'http://www.storefrontthemes.com';
$shortname = "storefront";

// Populate storefrontThemes option in array for use in theme
global $storefront_options;
$storefront_options = get_option('storefront_options');

$GLOBALS['template_path'] = get_bloginfo('template_directory');

//Access the WordPress Categories via an Array
$storefront_categories = array();
$storefront_categories_obj = get_categories('hide_empty=0');
foreach ($storefront_categories_obj as $storefront_cat) {
    $storefront_categories[$storefront_cat->cat_ID] = $storefront_cat->cat_name;}
$categories_tmp = array_unshift($storefront_categories, "Show All Posts");    
       
//Access the WordPress Pages via an Array
$storefront_pages = array();
$storefront_pages_obj = get_pages('sort_column=post_parent,menu_order');    
foreach ($storefront_pages_obj as $storefront_page) {
    $storefront_pages[$storefront_page->ID] = $storefront_page->post_name; }
$storefront_pages_tmp = array_unshift($storefront_pages, "Select a page:");

if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {	
	//Access the WooCommerce Product Categories via an Array
	$storefront_shop_categories = array();  
	$storefront_shop_categories_obj = get_categories(array('hide_empty' => 0,'taxonomy' => 'product_cat'));
	foreach ($storefront_shop_categories_obj as $storefront_shop_cat) {
	    $storefront_shop_categories[$storefront_shop_cat->cat_ID] = $storefront_shop_cat->cat_name;}
	$shop_categories_tmp = array_unshift($storefront_shop_categories, "Show All Products"); 
} elseif ( in_array( 'wp-e-commerce/wp-shopping-cart.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	//Access the WooCommerce Product Categories via an Array
	$storefront_shop_categories = array();  
	$storefront_shop_categories_obj = get_categories(array('hide_empty' => 0,'taxonomy' => 'wpsc_product_category'));
	foreach ($storefront_shop_categories_obj as $storefront_shop_cat) {
	    $storefront_shop_categories[$storefront_shop_cat->cat_ID] = $storefront_shop_cat->cat_name;}
	$shop_categories_tmp = array_unshift($storefront_shop_categories, "Show All Products");
} elseif ( in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	//Access the JigoShop Product Categories via an Array
	$storefront_shop_categories = array();  
	$storefront_shop_categories_obj = get_categories(array('hide_empty' => 0,'taxonomy' => 'product_cat'));
	foreach ($storefront_shop_categories_obj as $storefront_shop_cat) {
	    $storefront_shop_categories[$storefront_shop_cat->cat_ID] = $storefront_shop_cat->cat_name;}
	$shop_categories_tmp = array_unshift($storefront_shop_categories, "Show All Products");
}

// Image Alignment radio box
$options_thumb_align = array("alignleft" => "Left","alignright" => "Right","aligncenter" => "Center");
$options_slide_interval = array("300","400","500","600","700","800","900","1000","1100","1200","1300","1400","1500","1600","1700","1800","1900","2000");

$animationspeeds = array("300","400","500","600","700","800","900","1000","1100","1200","1300","1400","1500","1600","1700","1800","1900","2000");

$transspeeds = array("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15");

$homepage_carousel = array("" => "Don't Use the Carousel","carousel-show-products.php" => "Show Products","carousel-show-categories.php" => "Show Categories","carousel-show-posts.php" => "Show Posts");

// Select box border-radius
$options_pixels = array("0px","1px","2px","3px","4px","5px","6px","7px","8px","9px","10px","11px","12px","13px","14px","15px","16px","17px","18px","19px","20px");

//Testing 
//$options_select = array("one","two","three","four","five"); 
//$options_radio = array("one" => "One","two" => "Two","three" => "Three","four" => "Four","five" => "Five"); 

//More Options
$all_uploads_path = get_bloginfo('url') . '/wp-content/uploads/';
$all_uploads = get_option('storefront_uploads');
$other_entries = array("Select a number:","0","1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19");
$fonts = array("Abel","Antic","Changa One","Linden Hill","Quicksand","Terminal Dosis","Coda","Podkova","Questrial","Andika","Actor","Josephin Sans","News Cycle","Quattrocento","Josephin Slab","Yanone Kaffeesatz","Raleway");
$fontsizes = array("11px","12px","13px","14px","16px","18px","20px","22px","24px","26px","28px","30px","32px","36px","40px","44px","48px","52px","56px","60px");
// THESE ARE THE DIFFERENT FIELDS
$options = array();

	/*
	======================
	WELCOME
	======================
	*/
	
	$options[] = array( "name" => "Welcome","class" => "settings",
						"type" => "heading");
	
	$options[] = array( "name" => "<strong>Welcome to Storefront Echo!</strong>",
						"type" => "info",
						"std" => "<p>Congratulations! You just activated one of the most advanced WordPress eCommerce themes on the planet! This theme is unique for several reasons...</p>
<ul>
<li>- It works with <a href='http://getshopped.org' target='blank'>WP eCommerce!</a></li>
<li>- It works with <a href='http://www.woothemes.com/woocommerce/' target='blank'>WooCommerce!</a></li>
<li>- It works with <a href='http://www.jigoshop.com/' target='blank'>JigoShop!</a></li>
<li>- It works with <a href='http://www.buddypress.org' target='blank'>BuddyPress!</a></li>
<p>Not only is this theme compatible with the plugins above, but we've also taken extra care to make sure that we take advantage of the unique features of each, including the powerful ajax loading that come bundled with WooCommerce, JigoShop and BuddyPress.</p>
<p>We've made this theme as easy to use as possible, but we've also created a complete video tutorial to get you started. You can view it and access our support at the <a href='http://storefrontthemes.com' target='blank'>Storefront Themes</a> website. If you purchased from ThemeForest, you will first need to <a href='http://storefrontthemes.com/themeforest-user-registration' target='blank'>register your purchase</a>.</p>
<p>To get started, first click the 'Save all Changes' button to save the theme defaults. Good luck creating your site and don't forget to let us know once you're done at the <a href='http://storefrontthemes.com/showcase'  target='blank'>Storefront Themes Showcase!</a></p>
</ul>
						
						");

/*
======================
Logo
======================
*/

$options[] = array( "name" => "Logo","class" => "image",
					"type" => "heading");
					
$options[] = array( "name" => "Custom Logo",
					"desc" => "Upload a logo for your theme, or specify the image address of your online logo. (http://yoursite.com/logo.png)",
					"id" => $shortname."_logo",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Logo Text",
                    "desc" => "If you are using text instead of an image, enter your logo text here.",
                    "id" => $shortname."_logo_text",
                    "std" => "Your Logo",
                    "type" => "text");
					
$options[] = array( "name" => "Logo Font",
					"desc" => "Select which font you would like to use for your text-based logo.",
					"id" => $shortname."_logo_font",
					"type" => "select",
					"std" => "Changa One",
					"options" => $fonts);
					
$options[] = array( "name" => "Logo Font Size",
					"desc" => "Select a font-size for your text-based logo.",
					"id" => $shortname."_logo_font_size",
					"type" => "select",
					"std" => "36px",
					"options" => $fontsizes);
					
$options[] = array( "name" =>  "Logo Color",
					"desc" => "Customize the color of your site logo text.<br /><strong>NOTE: This is only if you are not using your own image for a logo, but rather just text.</strong>",
					"id" => $shortname."_logo_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" =>  "Logo Hover Color",
					"desc" => "Customize the color of your site logo text when hovered.<br /><strong>NOTE: This is only if you are not using your own image for a logo, but rather just text.</strong>",
					"id" => $shortname."_logo_hover_color",
					"std" => "",
					"type" => "color");

/*
======================
Style
======================
*/

$options[] = array( "name" => "Style","class" => "style",
					"type" => "heading");
					
$options[] = array( "name" =>  "Site Background Color",
					"desc" => "Customize your site's background color.",
					"id" => $shortname."_bg_color",
					"std" => "",
					"type" => "color");

$options[] = array( "name" => "Background Texture",
					"desc" => "Select a texture for your site background. This will appear above the background color you set above.<br /><strong>NOTE: Some textures may require a darker background color to show up well.</strong>",
					"id" => $shortname."_bg_texture",
					"std" => "sand",
					"type" => "select",
					"options" => array("none", "sand", "speckled", "crosshatch", "wood", "carpet") );
					
$options[] = array( "name" => "Background Image",
					"desc" => "Upload a background image, or specify the image address of your image. (http://yoursite.com/image.png). <strong>NOTE: You must select 'None' for your texture above for this to take effect.</strong>",
					"id" => $shortname."_bg_image",
					"std" => "",
					"type" => "upload");
					
$options[] = array( "name" => "Fix Background Image?",
					"desc" => "Check this if you want the background image to be fixed (no scrolling).",
					"id" => $shortname."_bg_image_fixed",
					"std" => "false",
					"type" => "checkbox");

$options[] = array( "name" => "Background Image Repeat",
					"desc" => "Select how you want your background image to display.",
					"id" => $shortname."_bg_image_repeat",
					"type" => "select",
					"options" => array("No Repeat" => "no-repeat", "Repeat" => "repeat","Repeat Horizontally" => "repeat-x", "Repeat Vertically" => "repeat-y", "Fixed" => "fixed",) );
					
$options[] = array( "name" => "Background Image Position",
					"desc" => "Select how you want your background image to be aligned.",
					"id" => $shortname."_bg_image_position",
					"type" => "select",
					"options" => array("Top Left" => "top left", "Top Right" => "top right", "Top Center" => "top center", "Bottom Left" => "bottom left", "Bottom Right" => "bottom right", "Bottom Center" => "bottom center",) );
					
$options[] = array( "name" => "Container Shadow",
                    "desc" => "Specify the radius in pixels of your container shadow (default is 4px).",
                    "id" => $shortname."_container_shadow_radius",
                    "std" => "",
                    "type" => "text");
					
$options[] = array( "name" => "Custom CSS",
                    "desc" => "Quickly add some CSS to your theme by adding it to this block.",
                    "id" => $shortname."_custom_css",
                    "std" => "",
                    "type" => "textarea");
					
/*
======================
Colors
======================
*/

$options[] = array( "name" => "Colors","class" => "colors",
					"type" => "heading");
					
$options[] = array( "name" => "Button Color",
					"desc" => "Select a color for the base of your gradient buttons.</strong>",
					"id" => $shortname."_button_color",
					"std" => "sand",
					"type" => "select",
					"options" => array("blue", "green", "red", "orange", "pink", "grey") );  
					
$options[] = array( "name" =>  "Frame Shadows Color",
					"desc" => "Customize color of the shadows around the main content frames (navigation bar, main site frame).",
					"id" => $shortname."_frame_shadow_color",
					"std" => "",
					"type" => "color");

$options[] = array( "name" =>  "Main Text Color",
					"desc" => "Customize the color of your main site text.",
					"id" => $shortname."_text_color",
					"std" => "",
					"type" => "color");

$options[] = array( "name" =>  "Links",
					"desc" => "Customize the color of links.",
					"id" => $shortname."_link_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" =>  "Nav Text",
					"desc" => "Customize the color of the navigation bar text.",
					"id" => $shortname."_nav_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" =>  "Bottom Content Text",
					"desc" => "Customize the color of text in the bottom content section (widgetized areas).",
					"id" => $shortname."_bottom_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" =>  "Bottom Content Links",
					"desc" => "Customize the color of links in the bottom content section (widgetized areas).",
					"id" => $shortname."_bottom_link_color",
					"std" => "",
					"type" => "color");

$options[] = array( "name" =>  "Footer Text",
					"desc" => "Customize the color of the footer text.",
					"id" => $shortname."_footer_color",
					"std" => "",
					"type" => "color");
					
$options[] = array( "name" =>  "Footer Links",
					"desc" => "Customize the color of the footer text.",
					"id" => $shortname."_footer_link_color",
					"std" => "",
					"type" => "color");
/* Check if BuddyPress is active*/
if ( in_array( 'buddypress/bp-loader.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {	
$options[] = array( "name" =>  "Nav Community Links Color",
					"desc" => "Customize color of the links in the Community Tab of your navigation.",
					"id" => $shortname."_community_links_color",
					"std" => "",
					"type" => "color");
}

/*
======================
Typography
======================
*/

$options[] = array( "name" => "Typography","class" => "typography",
					"type" => "heading"); 
					
$options[] = array( "name" => "Heading Font",
					"desc" => "Select which font you would like to use for your headings.",
					"id" => $shortname."_heading_font",
					"type" => "select",
					"std" => "Abel",
					"options" => $fonts);
					
$options[] = array( "name" => "H1 Heading Font Size",
					"desc" => "Select a font-size for your H1 heading tags.",
					"id" => $shortname."_heading_one_font_size",
					"type" => "select",
					"std" => "30px",
					"options" => $fontsizes);
					
$options[] = array( "name" => "H2 Heading Font Size",
					"desc" => "Select a font-size for your H2 heading tags.",
					"id" => $shortname."_heading_two_font_size",
					"type" => "select",
					"std" => "26px",
					"options" => $fontsizes);

$options[] = array( "name" => "Body Font",
					"desc" => "Select which font you would like to use for your main body text.",
					"id" => $shortname."_body_font",
					"type" => "select",
					"std" => "Abel",
					"options" => $fonts);
					
$options[] = array( "name" => "Body Font Size",
					"desc" => "Select a font-size for your body.",
					"id" => $shortname."_body_font_size",
					"type" => "select",
					"std" => "16px",
					"options" => $fontsizes);
					

/*
======================
Navigation
======================
*/

$options[] = array( "name" => "Navigation","class" => "navigation",
					"type" => "heading");
					
if ( in_array( 'buddypress/bp-loader.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) { 					
$options[] = array( "name" => "Show Community Icon in navigation?",
					"desc" => "Check this if you want to show a community icon which will house a dropdown menu to login/register and display links to your buddypress pages. This requires buddypress to work.",
					"id" => $shortname."_show_nav_community",
					"std" => "false",
					"type" => "checkbox");
}

$options[] = array( "name" => "Show search in navigation?",
					"desc" => "Check this if you want to show a search field in the navigation.",
					"id" => $shortname."_show_nav_search",
					"std" => "true",
					"type" => "checkbox");

$options[] = array( "name" => "Show cart total tab in navigation?",
					"desc" => "Check this if you want to show the cart total tab in the navigation.",
					"id" => $shortname."_show_nav_cart",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Show social icons on top of navigation?",
					"desc" => "If checked, this will allow for social icons to be shown above the navigation bar. Just enter your social addresses in the spaces below.",
					"id" => $shortname."_show_social_bar",
					"std" => "true",
					"type" => "checkbox");
					

/*
======================
Homepage Slider
======================
*/

$options[] = array( "name" => "Homepage Slider","class" => "home",
					"type" => "heading");
					
$options[] = array( "name" => "Show Slider?",
					"desc" => "Check this if you want to show the slider on your homepage.",
					"id" => $shortname."_show_slider",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Homepage Slider Height",
                    "desc" => "Please specify a height in pixels for your slider images. The slider width is 960px. Your slider images will need to be a minimum of this size to look correct.",
                    "id" => $shortname."_slider_height",
                    "std" => "365",
                    "type" => "text");

$options[] = array( "name" => "Slider Transition Speed",
                    "desc" => "How many seconds do you want to pause on each slide?.",
                    "id" => $shortname."_slider_trans_speed",
                    "std" => "5",
                    "type" => "select",
                    "options" => $transspeeds);
                    
$options[] = array( "name" => "Slider Animation Speed",
                    "desc" => "How fast do you want the transition between images to be? (in milliseconds)",
                    "id" => $shortname."_slider_anim_speed",
                    "std" => "500",
                    "type" => "select",
                    "options" => $animationspeeds);

/*
======================
Homepage Carousel
======================
*/

$options[] = array( "name" => "Homepage Carousel","class" => "home",
					"type" => "heading");
					
$options[] = array( "name" => "Show Carousel?",
					"desc" => "Check this if you want to show the carousel on your homepage. <strong>PLEASE NOTE: This carousel needs at least 5 products in order to work properly. You won't see your products until there are at least 5 products added</strong>.",
					"id" => $shortname."_show_carousel",
					"std" => "false",
					"type" => "checkbox");
					
$options[] = array( "name" => "Text Above Carousel",
                    "desc" => "Type the text you want to show above the carousel.",
                    "id" => $shortname."_carousel_text",
                    "std" => "Latest Products",
                    "type" => "text");
					
$options[] = array( "name" => "Carousel Height",
                    "desc" => "Please specify a height in pixels for your carousel images. Each image will be 200px in width.",
                    "id" => $shortname."_carousel_height",
                    "std" => "200",
                    "type" => "text");

if(isset($storefront_shop_categories)) {
$options[] = array(	"name" => "Carousel Product Category",
					"desc" => "You can select to show all products or products from a specific category in your carousel.",
					"id" => $shortname."_carousel_prod_category",
					"std" => "Select a category:",
					"type" => "select",
					"options" => $storefront_shop_categories);
					}
$options[] = array( "name" => "Carousel Transition Speed",
                    "desc" => "How many seconds do you want to pause on each set of images?",
                    "id" => $shortname."_carousel_trans_speed",
                    "std" => "7",
                    "type" => "select",
                    "options" => $transspeeds);
                    
$options[] = array( "name" => "Carousel Animation Speed",
                    "desc" => "How fast do you want the transition between sets of images to be? (in milliseconds)",
                    "id" => $shortname."_carousel_anim_speed",
                    "std" => "600",
                    "type" => "select",
                    "options" => $animationspeeds);
                    
					
/*
======================
Footer
======================
*/

$options[] = array( "name" => "Footer","class" => "footer",
					"type" => "heading");
					
$options[] = array( "name" => "Footer Text",
                    "desc" => "Add some text and basic html (strong, a, em, etc) here for the footer area.",
                    "id" => $shortname."_footer_text",
                    "std" => "",
                    "type" => "textarea");

/*
======================
SHOP SETTINGS
======================
*/
/*
$options[] = array( "name" => "Shop Settings","class" => "shop",
					"type" => "heading");

$options[] = array( "name" => "<strong>Shop Settings</strong>",
					"type" => "info",
					"std" => "<small>Here you can set some global options that will be used regardless of which eCommerce platform you choose.</small>");
					
$options[] = array( "name" => "Shorten Product Titles",
                    "desc" => "If you have some long product titles and would rather your product titles not span more than one line on the products page, you can enter a maximum value here so that they are automatically shortened and '...' is added to the end. For example, if you show your products in 6 columns, we recommend putting '34' in this area.",
                    "id" => $shortname."_product_title_shorten",
                    "std" => "",
                    "type" => "text");
*/

					
/* Check if WPEC is active*/
if ( in_array( 'wp-e-commerce/wp-shopping-cart.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {					
	/*
	======================
	WPEC SETTINGS
	======================
	*/
	
	$options[] = array( "name" => "WP-eCommerce","class" => "wpec",
						"type" => "heading");
	
	$options[] = array( "name" => "<strong>WP-eCommerce Settings</strong>",
						"type" => "info",
						"std" => "<p>You've activated the WP-eCommerce Plugin. Great! The settings below apply only to WP-e-Commerce. Most of your WPEC settings are controlled under <strong>'Settings > Store'</strong> but we've included some additional options below that are unique to this particular theme.</p>
						");
						
	$options[] = array(    "name" => "Product Image Link",
						"desc" => "On the default product page, choose whether the product image should link to the product or the full size image. Single Product page images will always link to the full size image.",
						"id" => $shortname."_product_image_link",
						"std" => "product",
						"type" => "select",
						"options" => array("product","image"));
						
	$options[] = array(    "name" => "Product Columns",
						"desc" => "Show your products in either 3, 4 or 6 columns on the product page.",
						"id" => $shortname."_product_columns",
						"std" => "4",
						"type" => "select",
						"options" => array("2","3","4","6"));
						
	$options[] = array( "name" => "Shorten Product Titles",
	                    "desc" => "If you have some long product titles and would rather your product titles not span more than one line on the products page, you can enter a maximum value here so that they are automatically shortened and '...' is added to the end. For example, if you show your products in 6 columns, we recommend putting '34' in this area.",
	                    "id" => $shortname."_product_title_shorten",
	                    "std" => "",
	                    "type" => "text");
                    
} //END OF CHECK FOR WPEC



/* Check if WooCommerce is active */
if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
                    
	/*
	======================
	WOOCOMMERCE SETTINGS
	======================
	*/
	
	$options[] = array( "name" => "WooCommerce","class" => "woocommerce",
						"type" => "heading");
						
	$options[] = array( "name" => "<strong>WooCommerce Settings</strong>",
						"type" => "info",
						"std" => "<p>You've activated the WooCommerce Plugin. Great! The settings below apply only to WooCommerce. Most of your WooCommerce settings are controlled under the <strong>'WooCommerce'</strong> tab but we've included some additional options below that are unique to this particular theme.</p>
						");					
						
	$options[] = array( "name" => "Products Per Page",
	                    "desc" => "You can set the number of products to show per page on your shop here. Default is 12.",
	                    "id" => $shortname."_woo_products_per_page",
	                    "std" => "12",
	                    "type" => "text");
	                    
	$options[] = array( "name" => "Shorten Product Titles",
	                    "desc" => "If you have some long product titles and would rather your product titles not span more than one line on the products page, you can enter a maximum value here so that they are automatically shortened and '...' is added to the end. For example, if you show your products in 6 columns, we recommend putting '34' in this area.",
	                    "id" => $shortname."_product_title_shorten",
	                    "std" => "",
	                    "type" => "text");
	                    
$options[] = array( "name" => "Show Breadcrumbs?",
					"desc" => "Check this if you want to show breadcrumbs on your single product pages.",
					"id" => $shortname."_woo_show_breadcrumbs",
					"std" => "false",
					"type" => "checkbox");
	                    
} //END OF CHECK FOR WOO



/* Check if JigoShop is active */
if ( in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
                    
	/*
	======================
	JigoShop SETTINGS
	======================
	*/
	
	$options[] = array( "name" => "JigoShop","class" => "jigoshop",
						"type" => "heading");
						
	$options[] = array( "name" => "<strong>JigoShop Settings</strong>",
						"type" => "info",
						"std" => "<p>You've activated the JigoShop Plugin. Great! The settings below apply only to JigoShop. Most of your JigoShop settings are controlled under <strong>'JigoShop > Settings'</strong> but we've included some additional options below that are unique to this particular theme.</p>");
						
	$options[] = array( "name" => "Products Per Page",
	                    "desc" => "You can set the number of products to show per page on your shop here. Default is 12. <strong>NOTE: This setting will override the setting provided in JigoShop settings.</strong>",
	                    "id" => $shortname."_woo_products_per_page",
	                    "std" => "",
	                    "type" => "text");

	                    
} //END OF CHECK FOR JIGOSHOP

					
/*
======================
Blog
======================
*/

$options[] = array( "name" => "Blog Settings","class" => "blog",
					"type" => "heading");
					
/* $options[] = array( "name" => "Default Blog Layout",
					"desc" => "Select which page layout you would like for your blog and archive pages.",
					"id" => $shortname."_blog_layout",
					"type" => "select",
					"std" => "Right Sidebar",
                    "options" => array("Right Sidebar", "Left Sidebar", "3 Column", "Full Width") );
                    
$options[] = array( "name" => "Single Blog Post Layout",
					"desc" => "Select which page layout you would like for your single blog posts.",
					"id" => $shortname."_blog_single_layout",
					"type" => "select",
					"std" => "Right Sidebar",
                    "options" => array("Right Sidebar", "Left Sidebar", "3 Column", "Full Width") );*/
                    
$options[] = array( "name" => "Blog Entry Content",
					"desc" => "Choose to show either the full post or an excerpt from each entry on the main blog page.",
					"id" => $shortname."_blog_content",
					"type" => "select",
					"options" => array("Full Post" => "Full Post", "Excerpt" => "Excerpt") );
					
$options[] = array( "name" => "Show Blog Author Section?",
					"desc" => "Check this to show the post author, avatar and description at the bottom of single posts.",
					"id" => $shortname."_blog_author_section",
					"std" => "true",
					"type" => "checkbox");
					
$options[] = array( "name" => "Blog Thumbnail Height",
					"desc" => "You can set your blog thumbnail image height here in pixels.  If this area is left blank, a default image height of 200px is used.",
					"id" => $shortname."_blog_image_height",
					"std" => "200",
					"type" => "text");
					
$options[] = array( "name" => "Blog Thumbnail Width",
					"desc" => "You can set your blog thumbnail image width here in pixels.  If this area is left blank, a default image width of 200px is used.",
					"id" => $shortname."_blog_image_width",
					"std" => "200",
					"type" => "text");
					
$options[] = array( "name" => "Featured Image Height",
					"desc" => "You can set your blog thumbnail image height here in pixels.  If this area is left blank, a default image height of 200px is used.",
					"id" => $shortname."_featured_image_height",
					"std" => "200",
					"type" => "text");
					
$options[] = array( "name" => "Featured Image Width",
					"desc" => "You can set your blog thumbnail image width here in pixels.  If this area is left blank, a default image width of 200px is used.",
					"id" => $shortname."_featured_image_width",
					"std" => "200",
					"type" => "text"); 


/*
======================
PressTrends
======================
*/ 

$options[] = array( "name" => "PressTrends","class" => "presstrends",
                    "type" => "heading"); 

$options[] = array( "name" => "<strong>PressTrends</strong>",
						"type" => "info",
						"std" => "<p><a href='http://www.presstrends.io/' target='blank'>PressTrends</a> is an independent service that allows us to work with our customers to get information on how our themes are being used and how we can make them better. It anonymously sends information to the PressTrends service (such as plugin usage, number of posts and comments, theme version, etc) once per day and then aggregates that information to give us a snapshot of how the average user is using our themes. No user information is collected and no site-specific information is shared with us. We only see the global averages for each theme. We can then share that information with the community and use it to build better themes. If you would like to opt out of this service, we have given you the option of turning this off by unchecking the box below.</p><p>If you would like to see current trends on how your site measures up to the community, you can also download the <a href='http://wordpress.org/extend/plugins/presstrends/' target='blank'>PressTrends plugin</a>.");
                                        
$options[] = array( "name" => "PressTrends",
                    "desc" => "If checked, this option will allow you to send metrics to PressTrends and provide Storefront Themes with insights.</strong> Thanks for helping us build better themes!",
                    "id" => $shortname."_presstrends",
                    "std" => "true",
                    "type" => "checkbox");


//endif;                                                           
update_option('storefront_template',$options);      
update_option('storefront_themename',$themename);   
update_option('storefront_shortname',$shortname);
update_option('storefront_manual',$manualurl);

$url =  get_bloginfo('template_url') . '/functions/images/';
}
?>