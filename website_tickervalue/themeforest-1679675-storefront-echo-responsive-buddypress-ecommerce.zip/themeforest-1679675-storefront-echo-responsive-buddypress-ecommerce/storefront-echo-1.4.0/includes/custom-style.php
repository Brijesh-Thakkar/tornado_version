<style>
body {
	<?php if ( get_option('storefront_body_font') ) { ?>font-family:<?php echo get_option('storefront_body_font'); ?>;<?php } ?>
	<?php if ( get_option('storefront_body_font_size') ) { ?>font-size:<?php echo get_option('storefront_body_font_size'); ?>;<?php } ?>
	<?php if ( get_option('storefront_bg_color') ) { ?>background-color:<?php echo get_option('storefront_bg_color'); ?>;<?php } ?>
	<?php if (get_option('storefront_bg_texture') == 'none' ) { ?>
		<?php if ( get_option('storefront_bg_image') ) { ?>background-image:url('<?php echo get_option('storefront_bg_image'); ?>');<?php } ?>
		<?php if ( get_option('storefront_bg_image_repeat') ) { ?>background-repeat:<?php echo get_option('storefront_bg_image_repeat'); ?>;<?php } ?>
		<?php if ( get_option('storefront_bg_image_position') ) { ?>background-position:<?php echo get_option('storefront_bg_image_position'); ?>;<?php } ?>
		<?php if ( get_option('storefront_bg_image_fixed') == 'true' ) { ?>background-attachment:fixed;<?php } ?>
	<?php } elseif (get_option('storefront_bg_texture')) { ?>
		background-image:url('<?php bloginfo( 'template_url' ); ?>/images/<?php echo get_option('storefront_bg_texture'); ?>.png');
		background-repeat:repeat;
	<?php } else {}?>
}

body a.button, body button.button, body input.button, body #review_form #submit,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body.jigoshop #review_form #submit,input[type="submit"] {<?php if ( get_option('storefront_body_font_size') ) { ?>font-size:<?php echo get_option('storefront_body_font_size'); ?>!important;<?php } ?><?php if ( get_option('storefront_body_font') ) { ?>font-family:<?php echo get_option('storefront_body_font'); ?>!important;<?php } ?>}

/* LOGO */
#logo a {<?php if ( get_option('storefront_logo_color') ) { echo 'color:'.get_option('storefront_logo_color').';';} ?>}
#logo a:hover {<?php if ( get_option('storefront_logo_hover_color') ) { echo 'color:'.get_option('storefront_logo_hover_color').';';} ?>}
#logo a {<?php if ( get_option('storefront_logo_font') ) { ?>font-family:<?php echo get_option('storefront_logo_font'); ?>;<?php } ?>}
#logo a {<?php if ( get_option('storefront_logo_font_size') ) { ?>font-size:<?php echo get_option('storefront_logo_font_size'); ?>;<?php } ?>}

/* HEADING */
h1 {<?php if ( get_option('storefront_heading_one_font_size') ) { ?>font-size:<?php echo get_option('storefront_heading_one_font_size'); ?>;<?php } ?>}
h2 {<?php if ( get_option('storefront_heading_two_font_size') ) { ?>font-size:<?php echo get_option('storefront_heading_two_font_size'); ?>;<?php } ?>}

#content h1, #content h2 {<?php if ( get_option('storefront_heading_font') ) { ?>font-family:<?php echo get_option('storefront_heading_font'); ?>;<?php } ?>}


/* TEXT */
body,body.woocommerce li.product a h3  {<?php if ( get_option('storefront_text_color') ) { echo 'color:'.get_option('storefront_text_color').';';} ?>}

/* BOX SHADOW */
.box,#content-bottom {<?php if ( get_option('storefront_container_shadow_radius') ) {
echo '-moz-box-shadow: 0px 0px '.get_option('storefront_container_shadow_radius').'px #000;';
echo '-webkit-box-shadow: 0px 0px '.get_option('storefront_container_shadow_radius').'px #000;';
echo 'box-shadow: 0px 0px '.get_option('storefront_container_shadow_radius').'px #000;';
} ?>}

/* BOTTOM CONTENT */
#content-bottom, #content-bottom h3 a {<?php if ( get_option('storefront_bottom_color') ) { echo 'color:'.get_option('storefront_bottom_color').';';} ?>}

#content-bottom a,#popupaddtocart a,#navcommunity a {<?php if ( get_option('storefront_bottom_link_color') ) { echo 'color:'.get_option('storefront_bottom_link_color').';';} ?>}

/* FOOTER */
#footer p {<?php if ( get_option('storefront_footer_color') ) { echo 'color:'.get_option('storefront_footer_color').';';} ?>}

#footer p a {<?php if ( get_option('storefront_footer_link_color') ) { echo 'color:'.get_option('storefront_footer_link_color').';';} ?>}

/* LINKS */
a,span.user-nicename {<?php if ( get_option('storefront_link_color') ) { echo 'color:'.get_option('storefront_link_color').';';} ?>}

ul#nav li a, a.navcart {<?php if ( get_option('storefront_nav_color') ) { echo 'color:'.get_option('storefront_nav_color').';';} ?>}

body div.item-list-tabs ul li a span {<?php if ( get_option('storefront_link_color') ) { echo 'background:'.get_option('storefront_link_color').';';} ?>}

#navcommunity a,#navcommunity a:hover {<?php if ( get_option('storefront_community_links_color') ) { echo 'color:'.get_option('storefront_community_links_color').';';} ?>}

/* FRAME SHADOWS */
#content .blueberry img {<?php if ( get_option('storefront_frame_shadow_color') ) { echo '
-moz-box-shadow:0px 0px 0px '.get_option('storefront_frame_shadow_color').';
-webkit-box-shadow:0px 0px 0px '.get_option('storefront_frame_shadow_color').';
 box-shadow:0px 0px 0px '.get_option('storefront_frame_shadow_color').';
';} ?>}

.box {<?php if ( get_option('storefront_frame_shadow_color') ) { echo '
-moz-box-shadow:0px 1px 4px '.get_option('storefront_frame_shadow_color').';
-webkit-box-shadow:0px 1px 4px '.get_option('storefront_frame_shadow_color').';
 box-shadow:0px 1px 4px '.get_option('storefront_frame_shadow_color').';
';} ?>}

/* BUTTON COLORS */
<?php if ( get_option('storefront_button_color') == 'blue' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		border-color: #4081AF!important; border-bottom-color: #20559A!important; background-color: #52A8E8;;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #52A8E8),color-stop(1, #2E76CF));
		background: -moz-linear-gradient(center top, #52A8E8 20%, #2E76CF 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body.jigoshop #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		 {
		background: #0073d2;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #3e9ee5),color-stop(1, #1666ca));
		background: -moz-linear-gradient(center top, #3e9ee5 20%, #1666ca 100%);
		}
<?php } ?>


<?php if ( get_option('storefront_button_color') == 'red' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop .cart-collaterals .shipping_calculator .button,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		border-color: #af4040!important; border-bottom-color: #9a2020!important; background-color: #d72323;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e85252),color-stop(1, #cf2e2e));
		background: -moz-linear-gradient(center top,#e85252 20%,#cf2e2e 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		 {
		background: #d20000;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e53e3e),color-stop(1, #ca1616));
		background: -moz-linear-gradient(center top,#e53e3e 20%,#ca1616 100%);
		}
<?php } ?>

<?php if ( get_option('storefront_button_color') == 'orange' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop .cart-collaterals .shipping_calculator .button,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		border-color: #af7440!important; border-bottom-color: #9a5420!important; background-color: #d76b23;
		background: #d25e00;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e57d3e),color-stop(1, #ca5116));
		background: -moz-linear-gradient(center top,#e57d3e 20%,#ca5116 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		{
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e88e52),color-stop(1, #cf6e2e));
		background: -moz-linear-gradient(center top,#e88e52 20%,#cf6e2e 100%);
		}
<?php } ?>

<?php if ( get_option('storefront_button_color') == 'green' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop .cart-collaterals .shipping_calculator .button,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		border-color: #87bf00!important; border-bottom-color: #7ca122!important; background-color: #8dc11e;
		background: #87c000;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #a0d53a),color-stop(1, #60b513));
		background: -moz-linear-gradient(center top,#a0d53a 20%,#60b513 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		{
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #ace53e),color-stop(1, #8dca16));
		background: -moz-linear-gradient(center top,#ace53e 20%,#6bca16 100%);
		}
<?php } ?>

<?php if ( get_option('storefront_button_color') == 'pink' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop .cart-collaterals .shipping_calculator .button,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		border-color: #d623cb!important; border-bottom-color: #9a2096!important; background-color: #d723d5;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e852e6),color-stop(1, #cd2ecf));
		background: -moz-linear-gradient(center top,#e852e6 20%,#cd2ecf 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		{
		background: #bc00d2;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #c83ee5),color-stop(1, #ae16ca));
		background: -moz-linear-gradient(center top,#c83ee5 20%,#ae16ca 100%);
		}
<?php } ?>

<?php if ( get_option('storefront_button_color') == 'grey' ) { ?>
	input[type="submit"], a.button,a.button.alt, button.button.alt, input.button.alt, #review_form #submit.alt,body.woocommerce-cart form.shipping_calculator button.button,body.jigoshop .button-alt,body.jigoshop .cart-collaterals .shipping_calculator .button,body.jigoshop a.button, body.jigoshop button.button, body.jigoshop input.button, body #review_form #submit,.searchedproduct a.button,body a.button,body button.button {
		color: #444 !important;
		text-shadow:0 1px #fff!important;
		border-color: #bbb!important; border-bottom-color: #999!important; background-color: #d8d8d8;
		background: #ccc;
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e0e0e0),color-stop(1, #bebebe));
		background: -moz-linear-gradient(center top,#e0e0e0 20%,#bebebe 100%);
	}
		a.button:hover,.custombutton:hover, .custombutton.hover, .custombutton.active, #content input[type="submit"]:hover, #content input[type="submit"].hover, #content input[type="submit"].active, #content input[type="button"]:hover, #content input[type="button"].hover, #content input[type="button"].active,a.button.alt:hover,a.button.alt.hover,a.button.alt.active, button.button.alt:hover,button.button.alt.hover,button.button.alt:active, input.button.alt:hover,input.button.alt.hover,input.button.alt:active, #review_form #submit.alt:hover,#review_form #submit.alt.hover,#review_form #submit.alt:active,body.woocommerce-cart form.shipping_calculator button.button:hover,body.woocommerce-cart form.shipping_calculator button.button:active,body.woocommerce-cart form.shipping_calculator button.button.hover,body.jigoshop .button-alt:hover,body.jigoshop .button-alt.hover,body.jigoshop .button-alt:active,body.jigoshop .cart-collaterals .shipping_calculator .button:hover,body.jigoshop a.button:hover, body.jigoshop button.button:hover, body.jigoshop input.button:hover, body #review_form #submit:hover,.searchedproduct a.button:hover,body a.button:hover,body button.button:hover
		{
		background: -webkit-gradient(linear,left top,left bottom,color-stop(.2, #e9e9e9),color-stop(1, #ccc));
		background: -moz-linear-gradient(center top,#e9e9e9 20%,#ccc 100%);
		}
<?php } ?>

/* Add the custom css from theme options */
<?php echo get_option('storefront_custom_css'); ?>

/* WooCommerce, JigoShop product pages */
<?php
if (in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	
	$wooimagewidth = 1 / (920 / get_option('woocommerce_single_image_width')) * 100;
	$woosummarywidth = 100 - $wooimagewidth - 4;
?>
	#entry div.product div.summary,#entry div.product .woocommerce_tabs, body.jigoshop #content #entry #tabs {width:<?php echo $woosummarywidth;?>%;}
	#entry div.product div.images {width:<?php echo $wooimagewidth;?>%;max-width:<?php echo get_option('woocommerce_single_image_width');?>px!important;}
	@media handheld, only screen and (max-width: 540px) {
	#content #entry ul.products li img {max-width:<?php echo get_option('woocommerce_catalog_image_width');?>px!important;}
	}
<?php } ?>




<?php
if (in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
	$jigoimagewidth = 1 / (920 / (get_option('jigoshop_shop_large_w') + 25)) * 100;
	/* Jigo Gridview */
	$jigocolumnwidth = 100 / (get_option('jigoshop_catalog_columns')) - 2;
	$jigosummarywidth = 100 - $jigoimagewidth - 4;
?>
	body.jigoshop #content #entry ul.products li {width:<?php echo $jigocolumnwidth;?>%!important;}
	#entry div.product div.summary,#entry div.product .woocommerce_tabs,body.jigoshop #content #entry #tabs {width:<?php echo $jigosummarywidth;?>%;}
	#entry div.product div.images {width:<?php echo $jigoimagewidth;?>%;max-width:<?php echo get_option('jigoshop_shop_large_w') + 14;?>px!important;}
	@media handheld, only screen and (max-width: 540px) {
	#content #entry ul.products li img {max-width:<?php echo get_option('jigoshop_shop_small_w');?>px!important;}

<?php } ?>


/*WOO SHOW BREADCRUMBS */

<?php if ( get_option('storefront_woo_show_breadcrumbs') == 'false' ) { ?>body.woocommerce #breadcrumb {display:none;}<?php } ?>


</style>
<!-- Load logo google font -->
<?php if ( get_option('storefront_logo_font') ) {
$logospaces = array(" ");
$logofont = get_option('storefront_logo_font');
$logofontstring = str_replace($logospaces, "+","$logofont")
?>
<link href='http://fonts.googleapis.com/css?family=<?php echo $logofontstring;?>' rel='stylesheet' type='text/css'>
<?php } ?>

<!-- Load body google font -->
<?php if ( get_option('storefront_body_font') ) {
$bodyspaces = array(" ");
$bodyfont = get_option('storefront_body_font');
$bodyfontstring = str_replace($bodyspaces, "+","$bodyfont")
?>
<link href='http://fonts.googleapis.com/css?family=<?php echo $bodyfontstring;?>' rel='stylesheet' type='text/css'>
<?php } ?>

<!-- Load heading google font -->
<?php if ( get_option('storefront_heading_font') ) {
$headingspaces = array(" ");
$headingfont = get_option('storefront_heading_font');
$headingfontstring = str_replace($headingspaces, "+","$headingfont")
?>
<link href='http://fonts.googleapis.com/css?family=<?php echo $headingfontstring;?>' rel='stylesheet' type='text/css'>
<?php } ?>
<!--[if gte IE 8]>
<style>
.single_product_display .imagecol img.product_image {margin-left: -40px;}
</style>
<![endif]-->