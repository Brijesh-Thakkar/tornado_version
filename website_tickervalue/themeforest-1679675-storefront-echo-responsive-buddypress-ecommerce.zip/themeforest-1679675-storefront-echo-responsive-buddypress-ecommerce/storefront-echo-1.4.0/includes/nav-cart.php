<?php if ( in_array( 'wp-e-commerce/wp-shopping-cart.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {?>

<a class="navcart" href="<?php echo get_option("shopping_cart_url");?>"><span class='cartcount'><?php echo wpsc_cart_total(); ?></span></a>

<?php } else if ( in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {?>

<a class="navcart" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'storefront'); ?>"><span class='cartcount'><?php echo $woocommerce->cart->get_cart_total(); ?></span></a>

<?php } else if ( in_array( 'jigoshop/jigoshop.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {?>

<a class="navcart" href="<?php echo jigoshop_cart::get_cart_url(); ?>" title="<?php _e('View your shopping cart', 'storefront'); ?>"><span class='cartcount'><?php echo jigoshop_cart::get_cart_total(); ?></span></a>

<?php } ?>

