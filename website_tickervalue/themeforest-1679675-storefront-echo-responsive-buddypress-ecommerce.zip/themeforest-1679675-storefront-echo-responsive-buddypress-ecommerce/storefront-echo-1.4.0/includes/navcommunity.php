<?php if ( is_user_logged_in() ) {?>
	<div id="navcommunity-loggedin">
			<a class="navcommunity-avatar" href="<?php bp_loggedin_user_link(); ?>">
			<?php bp_loggedin_user_avatar( 'width=75&height=75'); ?>
			</a>
			
			<h2 class="navcommunity-fullname">
				<a href="<?php bp_loggedin_user_link(); ?>"><?php bp_loggedin_user_fullname(); ?></a>
			</h2>
			<span class="navcommunity-username">@<?php bp_loggedin_user_username(); ?></span>
			<div class="clear"></div>
			<div class="underline"></div>
			

			
			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>messages/"><span class="icon messages"></span><?php _e('My Messages', 'storefrontthemes'); ?></a>
			
			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>messages/notices/"><span class="icon notices"></span></span><?php _e('My Notices', 'storefrontthemes'); ?></a>

			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>friends/"><span class="icon friends"></span><?php _e('My Friends', 'storefrontthemes'); ?></a>
			
			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>friends/requests/"><span class="icon requests"></span><?php _e('My Requests', 'storefrontthemes'); ?></a>

			<a class="navcommunity-loggedin-nav" href="<?php bloginfo('url'); ?>/groups/"><span class="icon allgroups"></span><?php _e('All Groups', 'storefrontthemes'); ?></a>
			
			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>groups/"><span class="icon groups"></span><?php _e('My Groups', 'storefrontthemes'); ?></a>
			
			<a class="navcommunity-loggedin-nav" href="<?php bloginfo('url'); ?>/activity/"><span class="icon siteactivity"></span><?php _e('Site Activity', 'storefrontthemes'); ?></a>
			
			<a class="navcommunity-loggedin-nav" href="<?php bp_loggedin_user_link(); ?>settings/"><span class="icon settings"></span><?php _e('My Settings', 'storefrontthemes'); ?></a>

		<span class="deletepopup hidecommunity"></span>	
	</div>
<?php } else {?>

<div id="navcommunity-notloggedin">
	<h3><?php _e('Join Our Community!', 'storefrontthemes'); ?></h3>
	<div class="underline"></div>
	<p><?php _e('Our community members enjoy interacting with each other, gaining access to groups and forums based around our products, and receiving exclusive content and promotional material. Sign up below to get connected!', 'storefrontthemes'); ?></p>
	<a class="button" href="<?php echo site_url( bp_get_signup_slug() . '/' );?>"><?php _e('Sign Up Now', 'storefrontthemes'); ?></a>
	<p style="margin-top:-5px;"><?php _e('Or...', 'storefrontthemes'); ?></p>
	<form name="loginform" class="buddypresslogin" id="login" action="<?php echo wp_login_url( get_permalink( $post->ID ) ); ?>" method="post">
	
		<div id="communityloginfields">
			<div id="communityloginleft">
				<input type="text" name="log" id="user_login" class="input" value="" maxlength="40" size="13" tabindex="1" />
				<label><?php _e('Username', 'storefrontthemes'); ?></label>
			</div>
			
			<div id="communityloginright">
				<input type="password" name="pwd" id="user_pass" class="input" value="" maxlength="40" size="13" tabindex="2" />
				<label><?php _e('Password', 'storefrontthemes'); ?></label>
			</div>
		</div>
		<input name="re" type="hidden" value="" />
		<input type="hidden" name="_wp_http_referer" value="/forums/" />
		<div class="clear"></div>
		<input type="submit" name="Submit" value="<?php _e('Log in', 'storefrontthemes'); ?>" tabindex="4" /><br />
		<!--<a href="http://storefrontthemes.com/forums/register.php">Register</a> | --><a href="<?php bloginfo('url'); ?>/wp-login.php?action=lostpassword"><?php _e('lost password?', 'storefrontthemes'); ?></a>
	</form>
	<span class="deletepopup hidecommunity"></span>
</div>
<?php }?>