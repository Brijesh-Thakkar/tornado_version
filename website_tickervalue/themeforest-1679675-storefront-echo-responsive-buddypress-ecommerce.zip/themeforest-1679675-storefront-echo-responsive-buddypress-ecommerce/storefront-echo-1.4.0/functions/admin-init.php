<?php 
/*-----------------------------------------------------------------------------------*/
/* storefrontThemes Framework Version & Theme Version */
/*-----------------------------------------------------------------------------------*/
function storefront_version_init(){
    $storefront_framework_version = '2.0';
    update_option('storefront_framework_version',$storefront_framework_version);
}
add_action('init','storefront_version_init');

function storefront_version(){  
    $theme_data = get_theme_data(TEMPLATEPATH . '/style.css');
    $theme_version = $theme_data['Version'];
    $storefront_framework_version = get_option('storefront_framework_version');
    echo '<meta name="generator" content="'. get_option('storefront_themename').' '. $theme_version .'" />' ."\n";
    echo '<meta name="generator" content="storefront Framework Version '. $storefront_framework_version .'" />' ."\n";
}
add_action('wp_head','storefront_version');

/*-----------------------------------------------------------------------------------*/
/* Load the required Framework Files */
/*-----------------------------------------------------------------------------------*/
$functions_path = TEMPLATEPATH . '/functions/';
require_once ($functions_path . 'admin-setup.php');			// Options panel variables and functions
require_once ($functions_path . 'admin-interface.php');		// Admin Interfaces (options,framework)
require_once ($functions_path . 'storefront-functions.php');// Extra Storefront Themes specific functionality
?>