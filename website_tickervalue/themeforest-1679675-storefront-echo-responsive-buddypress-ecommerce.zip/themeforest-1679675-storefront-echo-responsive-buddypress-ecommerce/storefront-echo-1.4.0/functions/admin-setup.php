<?php

/*-----------------------------------------------------------------------------------

TABLE OF CONTENTS

- Show Options Panel after activate
- Admin Backend
	- Tweaked the message on theme activate
- Theme Header ouput - wp_head()
	- Styles
	- Favicon
	- Decode	
	- Localization
	- Date Format
	- storefront_head_css
- Output CSS from standarized options
	- Text title
	- Custom.css
- Post Images from WP2.9+ integration

-----------------------------------------------------------------------------------*/

define('THEME_FRAMEWORK','storefrontthemes');

/*-----------------------------------------------------------------------------------*/
/* Add default options and show Options Panel after activate  */
/*-----------------------------------------------------------------------------------*/
if (is_admin() && isset($_GET['activated'] ) && $pagenow == "themes.php" ) {

	//Call action that sets
	add_action('admin_head','storefront_option_setup');
	
	//Do redirect
	header( 'Location: '.admin_url().'admin.php?page=storefrontthemes' ) ;
	
}

function storefront_option_setup(){

	//Update EMPTY options
	$storefront_array = array();
	add_option('storefront_options',$storefront_array);

	$template = get_option('storefront_template');
	$saved_options = get_option('storefront_options');
	
	foreach($template as $option) {
		if($option['type'] != 'heading'){
			$id = $option['id'];
			$std = $option['std'];
			$db_option = get_option($id);
			if(empty($db_option)){
				if(is_array($option['type'])) {
					foreach($option['type'] as $child){
						$c_id = $child['id'];
						$c_std = $child['std'];
						update_option($c_id,$c_std);
						$storefront_array[$c_id] = $c_std; 
					}
				} else {
					update_option($id,$std);
					$storefront_array[$id] = $std;
				}
			}
			else { //So just store the old values over again.
				$storefront_array[$id] = $db_option;
			}
		}
	}
	update_option('storefront_options',$storefront_array);
}

/*-----------------------------------------------------------------------------------*/
/* Admin Backend */
/*-----------------------------------------------------------------------------------*/
function storefrontthemes_admin_head() { 
	
	//Tweaked the message on theme activate
	?>
    <script type="text/javascript">
    jQuery(function(){
        var message = '<p>This <strong>storefrontTheme</strong> comes with a <a href="<?php echo admin_url('admin.php?page=storefrontthemes'); ?>">comprehensive options panel</a>. This theme also supports widgets, please visit the <a href="<?php echo admin_url('widgets.php'); ?>">widgets settings page</a> to configure them.</p>';
    	jQuery('.themes-php #message2').html(message);
    });
    </script>
    <?php
    
    //Setup Custom Navigation Menu
	if (function_exists('storefront_custom_navigation_setup')) {
		storefront_custom_navigation_setup();
	}
	
}

add_action('admin_head', 'storefrontthemes_admin_head'); 

/*-----------------------------------------------------------------------------------*/
/* Theme Header output - wp_head() */
/*-----------------------------------------------------------------------------------*/
function storefrontthemes_wp_head() { 
     
	// Custom.css insert
	echo '<link href="'. get_bloginfo('template_directory') .'/custom.css" rel="stylesheet" type="text/css" />'."\n";   
	
	// Favicon
	if(get_option('storefront_custom_favicon') != '') {
        echo '<link rel="shortcut icon" href="'.  get_option('storefront_custom_favicon')  .'"/>'."\n";
    }    
            
    //Decode
	if(!isset($_REQUEST['decode']))
		$decode = 'false';
	else
		$decode = $_REQUEST['decode'];
		
	if ($decode == 'true') 
		echo '<meta name="generator" content="' . get_option('storefront_settings_encode') . '" />';

	// Localization
	load_theme_textdomain('storefrontthemes');	
	
	// Date format
	$GLOBALS['storefrontdate'] = get_option('storefront_date');	
	if ( $GLOBALS['storefrontdate'] == "" )
		$GLOBALS['storefrontdate'] = "d. M, Y";	
		
	// Output CSS from standarized options
	storefront_head_css();

}
add_action('wp_head', 'storefrontthemes_wp_head');


/*-----------------------------------------------------------------------------------*/
/* Output CSS from standarized options */
/*-----------------------------------------------------------------------------------*/
function storefront_head_css() {

	$output = '';
	$text_title = get_option('storefront_texttitle');
    $custom_css = get_option('storefront_custom_css');

	$template = get_option('storefront_template');
	foreach($template as $option){
		if(isset($option['id'])){
			if($option['id'] == 'storefront_texttitle') {
				// Add CSS to output
				if ($text_title == "true") {
					$output .= '#logo img { display:none; }' . "\n";
					$output .= '#logo .site-title, #logo .site-description { display:block; } ' . "\n";
				} 
			}
		}
	}
	
	if ($custom_css <> '') {
		$output .= $custom_css . "\n";
	}
	
	// Output styles
	if ($output <> '') {
		$output = "<!-- storefront Styling -->\n<style type=\"text/css\">\n" . $output . "</style>\n";
		echo $output;
	}

}

/*-----------------------------------------------------------------------------------*/
/* */
/*-----------------------------------------------------------------------------------*/

?>