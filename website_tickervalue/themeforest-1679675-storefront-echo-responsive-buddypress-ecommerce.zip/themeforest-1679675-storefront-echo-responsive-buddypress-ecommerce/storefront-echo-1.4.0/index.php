<?php get_header(); ?>

				<div class="col_12">
					<div id="entry" class="pad20both pad20vertical">
					
					<?php if ( have_posts() ) : ?>
					<h1><?php _e( 'From the Blog...', 'storefront' ); ?></h1>
						<?php /* Start the Loop */ ?>
						<?php while ( have_posts() ) : the_post(); ?>
							<div class="post">
									
									<?php 
									if(has_post_thumbnail()) {
									if (get_option('storefront_blog_image_height')) {$blogimageheight = get_option('storefront_blog_image_height');}
									else {$blogimageheight = 200;}
									if (get_option('storefront_blog_image_width')) {$blogimagewidth = get_option('storefront_blog_image_width');}
									else {$blogimagewidth = 200;}
									$thumb = get_post_thumbnail_id(); 
									$image = vt_resize( $thumb, '', $blogimagewidth, $blogimageheight, true );
									$largeimage = vt_resize( $thumb, '', 900, 700, true );
									?>
									<a href="<?php echo $largeimage['url']; ?>" class="fancybox-image" rel="<?php the_title(); ?>">
									<img src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" />
									</a>
									<?php } ?>
									<h2><a href="<?php the_permalink();?>"><?php the_title(); ?></a></h2>
									
											<div class="post-meta">
											<p><span class="blogicon time"></span> <?php the_time('F j, Y \a\t g:i a') ?></p>
											<p><span class="blogicon cats"></span> <?php the_category(', ') ?>&nbsp;
											<?php the_tags( '<span class="blogicon tag"></span> ', ', ', ''); ?></p>
											</div>
									
									<?php if(get_option('storefront_blog_content') == "Excerpt") {the_excerpt();} else {the_content();} ?>
									<a class="button" href="<?php the_permalink();?>"><?php _e( 'Continue Reading...', 'storefront' ); ?></a>
									<div class="clear pad20bottom"></div>
									<div class="contenthr"></div>
									</div>
						<?php endwhile; ?>
						<?php if (  $wp_query->max_num_pages > 1 ) : ?>
										<div id="nav-below" class="navigation">
											<div class="nav-previous fl"><?php next_posts_link( __( '<span class="meta-nav">&larr;</span> Older posts', 'storefront' ) ); ?></div>
											<div class="nav-next fr"><?php previous_posts_link( __( 'Newer posts <span class="meta-nav">&rarr;</span>', 'storefront' ) ); ?></div>
										</div><!-- #nav-below -->
						<?php endif; ?>
					<?php else : ?>
							<h1><?php _e( 'Nothing Found', 'storefront' ); ?></h1>
							<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storefront' ); ?></p>
							<?php get_search_form(); ?>
					<?php endif; ?>
					</div>
				</div>

<?php get_footer(); ?>