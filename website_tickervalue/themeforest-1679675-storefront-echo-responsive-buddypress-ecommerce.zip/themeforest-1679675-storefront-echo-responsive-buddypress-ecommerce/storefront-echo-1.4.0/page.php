<?php get_header(); ?>


				<div class="col_12">
				
<?php 
	if(has_post_thumbnail()) {
	$thumb = get_post_thumbnail_id(); 
	$image = vt_resize( $thumb, '', 960, 500, true );
	?>
	
<img class="pagefeaturedimage" src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" />
<?php } ?>
				
					<div id="entry" class="pad20both pad20vertical">
						<?php if ( have_posts() ) : ?>
							<?php /* Start the Loop */ ?>
							<?php while ( have_posts() ) : the_post(); ?>
								<h1><?php the_title(); ?></h1>
								<?php the_content(); ?>
							<?php endwhile; ?>
						<?php else : ?>
								<h1><?php _e( 'Nothing Found', 'storefront' ); ?></h1>
								<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'twentyeleven' ); ?></p>
								<?php get_search_form(); ?>
						<?php endif; ?>
					</div><!-- #pad20both -->
				</div><!-- #col_12 -->

<?php get_footer(); ?>