<?php
/*-----------------------------------------------------------------------------------*/
/* Start storefrontThemes Functions - Please refrain from editing this section */
/*-----------------------------------------------------------------------------------*/

// Set path to storefrontFramework and theme specific functions
$functions_path = TEMPLATEPATH . '/functions/';
$includes_path = TEMPLATEPATH . '/includes/';

// storefrontFramework
require_once ($functions_path . 'admin-init.php');			// Framework Init

// Universal Storefront Functions
require_once ($functions_path . 'storefront-functions.php');			// Framework Init

// Theme specific functionality
require_once ($includes_path . 'theme-options.php'); 		// Options panel settings and custom settings
require_once ($includes_path . 'theme-functions.php'); 		// Custom theme functions
require_once ($includes_path . 'theme-js.php');				// Load javascript in wp_head

/*-----------------------------------------------------------------------------------*/
/* End storefrontThemes Functions - You can add custom functions below */
/*-----------------------------------------------------------------------------------*/
?>