<?php get_header(); ?>

				<div class="col_12">
					<div id="entry" class="pad20both pad20vertical">
					
					<?php if ( have_posts() ) : ?>
						<?php /* Start the Loop */ ?>
						<?php while ( have_posts() ) : the_post(); ?>
						
							<div id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
									
									<?php 
									if(has_post_thumbnail()) {
									if (get_option('storefront_featured_image_height')) {$blogimageheight = get_option('storefront_featured_image_height');}
									else {$blogimageheight = 200;}
									if (get_option('storefront_featured_image_width')) {$blogimagewidth = get_option('storefront_featured_image_width');}
									else {$blogimagewidth = 200;}
									$thumb = get_post_thumbnail_id(); 
									$image = vt_resize( $thumb, '', $blogimagewidth, $blogimageheight, true );
									$largeimage = vt_resize( $thumb, '', 900, 700, true );
									?>
									<a href="<?php echo $largeimage['url']; ?>" class="fancybox-image" rel="<?php the_title(); ?>">
									<img src="<?php echo $image['url']; ?>" width="<?php echo $image['width']; ?>" height="<?php echo $image['height']; ?>" />
									</a>
									<?php } ?>
									
															<h1><?php the_title(); ?></h1>
						
							<div class="post-meta">
							<span class="blogicon time"></span> <?php the_time('F j, Y \a\t g:i a') ?><br />
							<span class="blogicon cats"></span> <?php the_category(', ') ?>&nbsp;
							<?php the_tags( '<span class="blogicon tag"></span> ', ', ', ''); ?><br />
							</div>
									
									<?php the_content(); ?>
									
									<div class="clear pad20bottom"></div>
									
									<div class="contenthr"></div>
									
							<?php if (get_option('storefront_blog_author_section') == "true") {?>		
									<div class="author-bio">
										<h3><?php _e('About the Author', 'storefront') ?></h3>
										<div class="author-content">
											<?php echo get_avatar( get_the_author_meta('email'), '75' ); ?>
											<div class="author-description">
											<strong><?php the_author_meta("user_firstname"); ?> <?php the_author_meta("user_lastname"); ?></strong>
											<p><?php the_author_meta("description"); ?></p></div>
										</div>						
									</div>
									<div class="clear pad20bottom"></div>
									<div class="contenthr"></div>
							<?php } ?>
									
							<?php wp_link_pages('before=<p>&after=</p>&next_or_number=number&pagelink=page %'); ?>

									</div>
									<?php comments_template(); ?>
						<?php endwhile; ?>
					<?php else : ?>
							<h1><?php _e( 'Nothing Found', 'storefront' ); ?></h1>
							<p><?php _e( 'Apologies, but no results were found for the requested archive. Perhaps searching will help find a related post.', 'storefront' ); ?></p>
							<?php get_search_form(); ?>
					<?php endif; ?>
					</div>
				</div>

<?php get_footer(); ?>