To install this theme, please upload the theme zip file directly to WordPress under "Appearance > Themes > Install Themes"

Alternatively, you can unzip the theme folder and upload the unzipped folder to your "wp-content > themes" directory using FTP.

For support, please visit http://storefrontthemes.com/support

Users must first register for support at http://storefrontthemes.com/themeforest-user-registrationf